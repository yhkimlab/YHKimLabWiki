import sys, os
import glob
import matplotlib.pyplot as plt
import numpy as np

here = os.getcwd()

# Conversion parameters
ang2bohr = np.float64(1.889725989)

def get_PAV():
    
    sysname = glob.glob('*.RHO')[0]
    sysname = sysname.split('.')[0]
    cmd = 'grep ' + '"Total number of electrons: " stdout.txt > elec'
    os.system(cmd)
    f = open('elec', 'r')
    txt = f.readline()
    nelec = float(txt.split()[-1])
    f.close()
    os.system('rm elec')

    f = open('macroave.in', 'w')
    
    f.write('Siesta            # Which code have you used to get the input data?\n')
    f.write('Potential         # Which is the input data used to compute the band offset?\n')
    f.write('%s                # Name of the file where the input data is stored\n' %sysname)
    f.write('1                 # Number of convolutions required to calculate the macro. ave.\n')
    f.write('0                 # First length for the filter function in macroscopic average\n')
    f.write('0                 # Second length for the filter function in macroscopic average\n')
    f.write('%f                # Total charge\n'%nelec)
    f.write('spline            # Type of interpolation')
    
    f.close()
    
    os.system('macroave macroave.in')
    
    X = []
    E = []
    
    with open('%s.PAV' %sysname) as f:
        for i, l in enumerate(f):
            line = l
            word = line.split()
    
            X.append(float(word[0]))
            E.append(float(word[1]))
    f.close()

    X = np.array(X, dtype = np.float64)
    E = np.array(E, dtype = np.float64)
    os.system('rm macroave.in')

    return X, E

def plot_PAV(X, E):

    fig = plt.figure(figsize=[8,4])
    ax = fig.add_subplot(111)

    for axis in ['top','bottom','left','right']:
        ax.spines[axis].set_linewidth(3)
    ax.xaxis.set_tick_params(width=3, labelsize = 20)
    ax.yaxis.set_tick_params(width=3, labelsize = 20)

    ax.set_xlabel(r'Z [$\AA$]', fontsize=15)
    ax.set_ylabel(r'$\delta V_{H}$', fontsize=15)


    labels = [item.get_text() for item in ax.get_xticklabels()]
    empty_string_labels = ['']*len(labels)

    plt.plot(X, E, linewidth = 3, color = 'k')
    plt.tight_layout()
    plt.savefig('PAV.png')
    plt.close()

dir1 = sys.argv[1]
dir2 = sys.argv[2]

os.chdir(dir1)
x1, e1 = get_PAV()
os.chdir(here)

os.chdir(dir2)
x2, e2 = get_PAV()

os.chdir(here)
plot_PAV(x1/ang2bohr, e1-e2)
