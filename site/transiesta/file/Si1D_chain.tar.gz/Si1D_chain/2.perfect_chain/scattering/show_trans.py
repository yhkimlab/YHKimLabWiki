import sys
import numpy as np
import matplotlib.pyplot as plt


def get_xy_array(filename):

    lines = open(filename).readlines()
    x = []; y = []

    for line in lines:
        data=line.split()
        if data[0] != '#':
            x.append(float(data[0]))
            y.append(float(data[1]))
        #data = line.split()
        #x.append(float(data[0]))
        #y.append(float(data[1]))

    x = np.array(x)
    y = np.array(y)

    return x, y


fig = plt.figure(1, figsize=(8,5))
fig1 = fig.add_subplot(111)

style = ['k-', 'r--', 'b-.', 'g:']
#style = [ 'b-', 'g-']

i = 0
for arg in sys.argv[1:]:
    x, y = get_xy_array(arg)
    fig1.plot(x, y, style[i],label=arg.replace('/Tbtrans/scat.TBT.AVTRANS_Left-Right',''))
    fig1.tick_params(direction='in')
    i += 1

#fig1.axis([-5, 5, 0, 10])
fig1.axis([-10, 5, 0, 3])
fig1.set_xlabel('Energy [eV]', fontsize=15)
fig1.set_ylabel('Transmission', fontsize=15)
fig1.grid()
fig1.legend(fontsize=12)

plt.show()


